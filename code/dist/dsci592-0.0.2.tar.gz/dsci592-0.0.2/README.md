# DSCI 592: Capstone
## Modeling Covid-19 Mortality using Hierarchical Clustering and a Recurrent Neural Network 

